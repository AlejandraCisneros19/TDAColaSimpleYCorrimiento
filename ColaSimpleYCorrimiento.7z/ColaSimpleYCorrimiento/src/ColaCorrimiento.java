/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 52311
 */
public class ColaCorrimiento extends ColaSimple{
    
    public boolean insertar(char valor){
        if(fin==cola.length-1){
            if(ini>0){
                int recibe=0;
                for(int envia=ini; envia<=fin; envia++){
                    cola[recibe]=cola[envia];
                    recibe++;
                }
                ini=0;
                fin=recibe-1;
                return insertar(valor);
            }
            return false;
        }
        fin++;
        cola[fin]=valor;
        if(ini==-1 && fin==0){
            ini++;
        }
        return true;
    }
    
}
